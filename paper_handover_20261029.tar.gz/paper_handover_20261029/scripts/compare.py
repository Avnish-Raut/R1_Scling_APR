#!/usr/bin/env python3
"""
compare_anchor_rules.py  --  decide the anchoring rule from evidence

    python3 compare_anchor_rules.py /home/research_slicing/slicer4j/results Lang

Three candidate rules for where to anchor an omission fault, all applied to
the SAME saved per-bug artefacts, so no slicing is rerun:

  A  fwd_unbounded   scan forward from the insertion point for the next
                     statement, with no limit.
                     == what the overnight run actually did.

  B  adjacent        anchor forward only if the insertion point is itself a
                     statement line, else the preceding statement.
                     == the rule I proposed after Lang 5; WRONG, because an
                        insertion into a comment block then falls backwards
                        past unrelated code (Lang 45).

  C  scope_stop      scan forward like A, but stop at the end of the
                     enclosing method or at a declaration. Comments, blanks
                     and inner braces are crossed; method boundaries are not.

Rule A is validated against the CSV first. It must reproduce patch_total and
patch_in_slice exactly, because it is the rule the run used. If it does not,
something else is wrong and the comparison is meaningless -- the script says
so rather than producing numbers.

Inputs per bug, under <results>/<Project>/<bug>/:
    patched_raw.txt              raw loci (line, DELETED|INSERT_AT)
    stmt_lines.txt               which lines are statements
    modclass.java                the buggy source of the modified class
    slice_modclass_<variant>.txt the slice, restricted to that class

Writes <Project>_rq_ruleC.csv and rule_comparison.txt. Originals untouched.
"""

import os
import sys
import glob
import csv
from collections import Counter

# ---------------------------------------------------------------------------
# Brace depth, with literals and comments removed first.
#
# Counting raw { and } would be derailed by braces inside strings ("{}"),
# char literals ('{') and comments. This is not a Java parser, but it is
# accurate enough for nesting depth in ordinary source.
# ---------------------------------------------------------------------------

def strip_code(lines):
    out = []
    in_block = False
    for raw in lines:
        s, i, n = [], 0, len(raw)
        while i < n:
            c = raw[i]
            if in_block:
                if c == "*" and i + 1 < n and raw[i + 1] == "/":
                    in_block = False
                    i += 2
                    continue
                i += 1
                continue
            if c == "/" and i + 1 < n and raw[i + 1] == "/":
                break                                   # line comment
            if c == "/" and i + 1 < n and raw[i + 1] == "*":
                in_block = True
                i += 2
                continue
            if c in ('"', "'"):
                q = c
                i += 1
                while i < n:
                    if raw[i] == "\\":
                        i += 2
                        continue
                    if raw[i] == q:
                        i += 1
                        break
                    i += 1
                continue
            s.append(c)
            i += 1
        out.append("".join(s))
    return out


def brace_depths(lines):
    """depth_before[i] = nesting depth at the START of 1-based line i+1."""
    clean = strip_code(lines)
    before, d = [], 0
    for c in clean:
        before.append(d)
        d += c.count("{") - c.count("}")
    return before


DECL_PREFIX = ("public ", "protected ", "private ",
               "class ", "interface ", "enum ", "record ",
               "@interface ")
MOD_NO_ACCESS = ("abstract ", "final ", "static ", "synchronized ",
                 "native ", "strictfp ", "default ")


def decl_lines(lines):
    """Line numbers (1-based) that begin a declaration or close the class."""
    out = set()
    for n, raw in enumerate(lines, 1):
        if raw.startswith("}"):                  # class-level close, col 0
            out.add(n)
            continue
        t = raw.strip()
        if not t:
            continue
        if t.startswith(DECL_PREFIX):
            out.add(n)
            continue
        if t.startswith("static {") or t == "static":
            out.add(n)
            continue
        # method signature with no access modifier: "final void f() {"
        if (t.endswith("{") and "(" in t
                and t.startswith(MOD_NO_ACCESS)
                and not t.startswith("synchronized (")):
            out.add(n)
    return out


# ---------------------------------------------------------------------------
# The three rules
# ---------------------------------------------------------------------------

def prev_stmt(line, stmt):
    i = line - 1
    while i >= 1:
        if i in stmt:
            return i
        i -= 1
    return None


def fwd_unbounded(line, stmt, maxl):
    i = line
    while i <= maxl:
        if i in stmt:
            return i
        i += 1
    return None


def fwd_scope(line, stmt, maxl, depth, decls):
    """
    Forward scan that refuses to leave the enclosing method.

    Floor: the insertion point's own depth, capped at 2, so a statement that
    sits just outside a nested block but inside the same method is still
    acceptable, while the method's own closing brace stops the scan.
    """
    if line - 1 < len(depth):
        d0 = depth[line - 1]
    else:
        d0 = 2
    floor = d0 if d0 <= 2 else 2

    i = line
    while i <= maxl:
        if i in decls:
            return None                       # crossed into a declaration
        if i - 1 < len(depth) and depth[i - 1] < floor:
            return None                       # left the method
        if i in stmt:
            return i
        i += 1
    return None


def resolve(raw, stmt, rule, depth=None, decls=None):
    maxl = max(stmt) if stmt else 0
    primary, back, kinds = set(), set(), []

    for line, kind in raw:
        if kind == "DELETED":
            if line in stmt:
                primary.add(line)
                back.add(line)
                kinds.append((line, "DELETED"))
            continue

        b = prev_stmt(line, stmt)
        if b is not None:
            back.add(b)

        if rule == "A":
            f = fwd_unbounded(line, stmt, maxl)
        elif rule == "B":
            f = line if line in stmt else None
        else:
            f = fwd_scope(line, stmt, maxl, depth or [], decls or set())

        if f is not None:
            primary.add(f)
            kinds.append((f, "ANCHOR_FWD"))
        elif b is not None:
            primary.add(b)
            kinds.append((b, "ANCHOR_TAIL"))

    return primary, back, kinds


def fault_kind(kinds):
    ks = {k for _, k in kinds}
    d = "DELETED" in ks
    a = any(k.startswith("ANCHOR_") for k in ks)
    return "MIXED" if (d and a) else "DELETED" if d else "ADDITIVE" if a else "NONE"


def coverage(hit, total):
    if total <= 0:
        return ""
    return "NONE" if hit == 0 else "FULL" if hit >= total else "PARTIAL"


def read_ints(path):
    out = set()
    try:
        with open(path) as f:
            for ln in f:
                ln = ln.strip()
                if ln:
                    try:
                        out.add(int(ln.split()[0]))
                    except ValueError:
                        pass
    except OSError:
        pass
    return out


def read_raw(path):
    out = []
    try:
        with open(path) as f:
            for ln in f:
                p = ln.rstrip("\n").split("\t")
                if len(p) >= 2 and p[0].strip():
                    try:
                        out.append((int(p[0].strip()), p[1].strip()))
                    except ValueError:
                        pass
    except OSError:
        return None
    return out


def main():
    if len(sys.argv) < 2:
        sys.exit("Usage: compare_anchor_rules.py <results-dir> [project]")
    root = sys.argv[1]
    only = sys.argv[2] if len(sys.argv) > 2 else None

    files = sorted(glob.glob(os.path.join(root, "*_rq.csv")))
    if only:
        files = [f for f in files
                 if os.path.basename(f).startswith(only + "_")]
    if not files:
        sys.exit("No matching *_rq.csv in " + root)

    report = []
    def say(s=""):
        print(s)
        report.append(str(s))

    for csv_path in files:
        say("=" * 76)
        say("FILE: " + os.path.basename(csv_path))
        say("=" * 76)

        with open(csv_path, newline="") as f:
            rows = list(csv.reader(f))
        header, data = rows[0], rows[1:]
        idx = {c: i for i, c in enumerate(header)}

        bugs = sorted({r[idx["bug"]] for r in data}, key=int)
        info = {}
        no_src = []

        for bug in bugs:
            proj = next(r[idx["project"]] for r in data if r[idx["bug"]] == bug)
            d = os.path.join(root, proj, bug)
            raw = read_raw(os.path.join(d, "patched_raw.txt"))
            stmt = read_ints(os.path.join(d, "stmt_lines.txt"))
            if raw is None or not stmt:
                info[bug] = None
                continue

            src_path = os.path.join(d, "modclass.java")
            if os.path.exists(src_path):
                with open(src_path, errors="replace") as f:
                    src = f.read().split("\n")
                depth = brace_depths(src)
                decls = decl_lines(src)
            else:
                src, depth, decls = None, [], set()
                no_src.append(bug)

            A, back, kA = resolve(raw, stmt, "A")
            B, _, _ = resolve(raw, stmt, "B")
            C, _, kC = resolve(raw, stmt, "C", depth, decls)
            info[bug] = {"dir": d, "raw": raw, "stmt": stmt, "src": src,
                         "A": A, "B": B, "C": C, "back": back,
                         "kindC": fault_kind(kC)}

        usable = [b for b in bugs if info[b]]
        say("bugs with loci: %d    missing modclass.java: %d %s"
            % (len(usable), len(no_src),
               ("(" + ",".join(no_src) + ")") if no_src else ""))
        if no_src:
            say("  rule C falls back to rule A for those -- fetch the sources")
        say()

        # -------- validate rule A against the CSV -------------------------
        ok = bad = skip = 0
        examples = []
        for r in data:
            bug, var = r[idx["bug"]], r[idx["variant"]]
            c = info.get(bug)
            if not c:
                skip += 1
                continue
            try:
                t = int(r[idx["patch_total"]] or 0)
            except ValueError:
                skip += 1
                continue
            if t != len(c["A"]):
                bad += 1
                if len(examples) < 5:
                    examples.append("  bug %s %s: csv total=%d, rule A=%d"
                                    % (bug, var, t, len(c["A"])))
                continue
            if r[idx["status"]] != "OK" or r[idx["patch_in_slice"]] == "":
                ok += 1
                continue
            sl = read_ints(os.path.join(c["dir"],
                                        "slice_modclass_%s.txt" % var))
            got = len(c["A"] & sl)
            want = int(r[idx["patch_in_slice"]])
            if got == want:
                ok += 1
            else:
                bad += 1
                if len(examples) < 5:
                    examples.append("  bug %s %s: csv hit=%d, rule A=%d"
                                    % (bug, var, want, got))

        say("VALIDATION -- rule A must reproduce the run")
        say("  reproduced %d    mismatched %d    not checkable %d"
            % (ok, bad, skip))
        for e in examples:
            say(e)
        if bad:
            say("  *** rule A does not reproduce the run. Stop and")
            say("  *** investigate before trusting anything below.")
        say()

        # -------- how much do the rules disagree? -------------------------
        dAB = [b for b in usable if info[b]["A"] != info[b]["B"]]
        dAC = [b for b in usable if info[b]["A"] != info[b]["C"]]
        dBC = [b for b in usable if info[b]["B"] != info[b]["C"]]
        say("RULE DISAGREEMENT (bugs)")
        say("  A (run, unbounded fwd)  vs  B (adjacent)    : %d" % len(dAB))
        say("  A (run, unbounded fwd)  vs  C (scope stop)  : %d  <-- the one that matters"
            % len(dAC))
        say("  B (adjacent)            vs  C (scope stop)  : %d" % len(dBC))
        say()

        if dAC:
            say("WHERE A AND C DIFFER  (A = what the run used, C = corrected)")
            for b in dAC:
                c = info[b]
                ins = sorted({l for l, k in c["raw"] if k == "INSERT_AT"})
                say("  bug %s   insert@%s   A=%s   C=%s"
                    % (b, ins, sorted(c["A"]), sorted(c["C"])))
                if c["src"]:
                    for ln in sorted(set(list(c["A"]) + list(c["C"]))):
                        if 1 <= ln <= len(c["src"]):
                            tag = ("A" if ln in c["A"] else " ") + \
                                  ("C" if ln in c["C"] else " ")
                            say("      [%s] %5d  %s"
                                % (tag, ln, c["src"][ln - 1].strip()[:70]))
            say()
        else:
            say("A and C agree on every bug: the run's anchors were already")
            say("inside the enclosing method, so nothing needs correcting.")
            say()

        # -------- write rule C csv ----------------------------------------
        out = csv_path.replace("_rq.csv", "_rq_ruleC.csv")
        moves = Counter()
        head_changed = set()
        with open(out, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(header)
            for r in data:
                r = list(r)
                bug, var = r[idx["bug"]], r[idx["variant"]]
                c = info.get(bug)
                if not c:
                    w.writerow(r)
                    continue
                P, back = c["C"], c["back"]
                r[idx["patch_total"]] = str(len(P))
                if "fault_kind" in idx:
                    r[idx["fault_kind"]] = c["kindC"]
                if "patch_total_back" in idx:
                    r[idx["patch_total_back"]] = str(len(back))
                if r[idx["status"]] == "OK":
                    sl = read_ints(os.path.join(
                        c["dir"], "slice_modclass_%s.txt" % var))
                    hit = len(P & sl)
                    newc = coverage(hit, len(P))
                    if r[idx["coverage"]] != newc:
                        moves["%s: %s -> %s"
                              % (var, r[idx["coverage"]], newc)] += 1
                    r[idx["patch_in_slice"]] = str(hit)
                    r[idx["coverage"]] = newc
                    if "patch_in_slice_back" in idx:
                        r[idx["patch_in_slice_back"]] = str(len(back & sl))
                if c["A"] != c["C"] and c["A"] and P and min(c["A"]) != min(P):
                    head_changed.add(bug)
                w.writerow(r)

        say("COVERAGE MOVEMENT, A -> C")
        if moves:
            for k, v in sorted(moves.items(), key=lambda x: -x[1]):
                say("  %-42s %d" % (k, v))
        else:
            say("  none")
        say()
        if head_changed:
            say("FIRST LOCUS CHANGED (the `patched` criterion) -- rerun these:")
            say("  " + " ".join(sorted(head_changed, key=int)))
        else:
            say("FIRST LOCUS CHANGED: none -- no rerun needed for `patched`.")
        say()
        say("wrote " + out)
        say()

    rp = os.path.join(root, "rule_comparison.txt")
    with open(rp, "w") as f:
        f.write("\n".join(report) + "\n")
    print("report: " + rp)


if __name__ == "__main__":
    main()
