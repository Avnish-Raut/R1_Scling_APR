#!/bin/bash

###############################################################################
# is_app_class <fully.qualified.ClassName>
#
# True when the class has a source file under the APPLICATION source root.
#
# Name-based classification ("is it the trigger test class?") breaks on
# inherited test methods: the stack reports the superclass that declares the
# method, not the subclass the test ran under. Source-root membership is
# unambiguous.
#
# Call from inside the checkout ($WS), with SRC_REL set.
###############################################################################
is_app_class () {
    local CLS="$1"
    local TOP="${CLS%%\$*}"                       # strip inner-class suffix
    local REL="$(echo "$TOP" | tr '.' '/').java"
    [ -n "$SRC_REL" ] && [ -f "$SRC_REL/$REL" ]
}

###############################################################################
#
# run_slicer_rq.sh
#
# Slicer4J batch runner built around the research questions.
#
# KEY STRUCTURAL POINT
# --------------------
# Instrumentation and tracing are IDENTICAL for every slicing criterion of a
# given bug. Only the final "-m s" step depends on the criterion.
#
# So the expensive work happens once per bug, and criteria are then swept
# cheaply:
#
#     checkout -> compile -> test -> jar -> instrument -> trace     (once)
#                                                          |
#                          +---------------+---------------+
#                          |               |               |
#                       slice C1        slice C2        slice C3   (cheap)
#
# This makes RQ1 (criterion sensitivity) nearly free. Without it, each extra
# criterion would cost a full re-trace.
#
# OUTPUT
# ------
# One CSV row per (bug, criterion) pair, so criteria can be compared directly.
#
# CRITERION VARIANTS
# ------------------
#   test_crash    The line in the TEST where the failure surfaced (top frame
#                 of the stack trace inside the test class).
#                 This is the principled default: it mirrors real debugging,
#                 where the symptom is known and the cause is not.
#
#   app_deepest   The deepest stack frame inside APPLICATION code. Closer to
#                 the fault, so slices should be smaller -- but it assumes
#                 knowledge a developer would not have at the start.
#
#   patched       A line the developer actually changed. Useful for slice-size
#                 questions, but NOTE the criterion is then inside the slice by
#                 construction, so fault coverage from this variant is
#                 CIRCULAR and must not be reported as a coverage result.
#                 Included precisely so the circularity can be quantified.
#
# Usage:
#   ./run_slicer_rq.sh <Project> [MaxBugs]
#
###############################################################################

set -u

###############################################################################
# CONFIGURATION
###############################################################################

ROOT="/home/research_slicing"

D4J_HOME="$ROOT/defects4j-2.0.0/"
D4J="$D4J_HOME/framework/bin/defects4j"
D4J_JUNIT=$(find "$D4J_HOME/framework/projects/lib" -name 'junit*.jar' 2>/dev/null | head -1)
SLICER4J_JAR="$ROOT/tools/vendor_frameworks/Slicer4J/Slicer4J/target/slicer4j-jar-with-dependencies.jar"
LOGGER_JAR="$ROOT/tools/vendor_frameworks/DynamicSlicingCore/DynamicSlicingLoggingClasses/DynamicSlicingLogger.jar"
SLICER4J_HOME="$ROOT/tools/vendor_frameworks/Slicer4J"

WORK_BASE="$ROOT/slicer4j/work"
RESULT_BASE="$ROOT/slicer4j/results"
LOG_BASE="$ROOT/slicer4j/logs"

T_CHECKOUT=600
T_COMPILE=900
T_TEST=900
T_INSTRUMENT=1200
T_TRACE=1800
T_SLICE=1200

HEAP="24g"

# Which criterion variants to run. Comment out to skip.
VARIANTS="test_crash app_deepest patched"

# Cap on how many patched lines to use as criteria (they are the same bug,
# so a handful is enough and avoids one large patch dominating the data).
MAX_PATCHED_CRITERIA=3

KEEP_WORKSPACE=0


###############################################################################
# ARGUMENTS
###############################################################################

if [ "$#" -lt 1 ] || [ "$#" -gt 2 ]; then
    echo "Usage: ./run_slicer_rq.sh <Project> [MaxBugs]"
    exit 1
fi

PROJECT="$1"
MAX_BUGS="${2:-0}"

mkdir -p "$WORK_BASE" "$RESULT_BASE" "$LOG_BASE"

CSV="$RESULT_BASE/${PROJECT}_rq.csv"

if [ ! -f "$CSV" ]; then
cat > "$CSV" <<'HDR'
project,bug,variant,criterion,status,slice_lines,slice_classes,slice_methods,executed_lines,executed_classes,modclass_lines,project_lines,red_vs_executed,red_vs_modclass,patch_total,patch_in_slice,coverage,t_setup,t_instrument,t_trace,t_slice,trace_bytes,trace_size,icdg_bytes,slice_modclass,fault_kind,patch_total_back,patch_in_slice_back
HDR
fi

# Resume: skip a bug if any row for it already exists.
bug_done () {
    cut -d, -f2 "$CSV" | grep -qx "$1"
}


###############################################################################
# BUG LIST -- active-bugs.csv, because IDs are not contiguous
###############################################################################

ACTIVE_CSV="$D4J_HOME/framework/projects/$PROJECT/active-bugs.csv"

if [ -f "$ACTIVE_CSV" ]; then
    BUGS=$(tail -n +2 "$ACTIVE_CSV" | cut -d, -f1)
else
    BUGS=$("$D4J" query -p "$PROJECT" -q "bug.id" 2>/dev/null | cut -d, -f1)
fi

[ -z "$BUGS" ] && { echo "ERROR: no bug list for $PROJECT"; exit 1; }

TOTAL=$(echo "$BUGS" | grep -c .)

echo "=============================================="
echo "Slicer4J RQ run: $PROJECT  ($TOTAL bugs)"
echo "Variants: $VARIANTS"
echo "=============================================="


###############################################################################
# HELPERS
###############################################################################

pct () {
    local s="$1" b="$2"
    [ -z "$b" ] && { echo ""; return; }
    [ "$b" -eq 0 ] 2>/dev/null && { echo ""; return; }
    awk -v s="$s" -v b="$b" 'BEGIN{printf "%.2f", 100*(1-s/b)}'
}

row () {
    echo "$PROJECT,$BUG,$1,$2,$3,$4,$5,$6,$EXEC_LINES,$EXEC_CLASSES,$MODCLASS_LINES,$PROJ_LINES,$7,$8,$PATCH_TOTAL,$9,${10},$T_SETUP,$T_INS,$T_TRC,${11},$TRACE_BYTES,$TRACE_SIZE,$ICDG_BYTES,$SL_MOD,$FAULT_KIND,$PATCH_TOTAL_BACK,$PHIT_BACK" >> "$CSV"
}

# Emit a failure row for every variant, so a failed bug is visible in each
# variant's population rather than silently absent.
fail_all () {
    for V in $VARIANTS; do
        echo "$PROJECT,$BUG,$V,,$1,,,,,,,,,,,,,$T_SETUP,$T_INS,$T_TRC,,$TRACE_BYTES,$TRACE_SIZE,$ICDG_BYTES," >> "$CSV"
    done
    echo "  => $1"
}


###############################################################################
# MAIN LOOP
###############################################################################

COUNT=0

[ -n "${ONLY_BUGS:-}" ] && BUGS="$ONLY_BUGS"
for BUG in $BUGS
do
    COUNT=$((COUNT+1))
    [ "$MAX_BUGS" -gt 0 ] && [ "$COUNT" -gt "$MAX_BUGS" ] && break

    if bug_done "$BUG"; then
        echo "[$COUNT/$TOTAL] $PROJECT $BUG -- done, skipping"
        continue
    fi

    echo
    echo "--------------------------------------------------"
    echo "[$COUNT/$TOTAL] $PROJECT bug $BUG"

    T_SETUP=""; T_INS=""; T_TRC=""; TRACE_BYTES=""
    TRACE_SIZE="";ICDG_BYTES=""
    EXEC_LINES=""; EXEC_CLASSES=""; MODCLASS_LINES=""; PROJ_LINES=""
    PATCH_TOTAL=""; SL_MOD=""; FAULT_KIND="";PATCH_TOTAL_BACK=0 ;PHIT_BACK=""

    WS="$WORK_BASE/$PROJECT/$BUG"
    RES="$RESULT_BASE/$PROJECT/$BUG"
    LOGD="$LOG_BASE/$PROJECT/$BUG"

    rm -rf "$WS"; mkdir -p "$WS" "$RES" "$LOGD"

    SETUP_START=$(date +%s)

    # ======================= PHASE A: once per bug ========================

    if ! timeout "$T_CHECKOUT" "$D4J" checkout -p "$PROJECT" -v "${BUG}b" -w "$WS" \
            > "$LOGD/checkout.log" 2>&1; then
        fail_all "CHECKOUT_FAILED"; rm -rf "$WS"; continue
    fi

    cd "$WS" || { fail_all "CD_FAILED"; continue; }

    if ! timeout "$T_COMPILE" "$D4J" compile > "$LOGD/compile.log" 2>&1; then
        cd "$ROOT"; fail_all "COMPILE_FAILED"; rm -rf "$WS"; continue
    fi

    # A non-zero exit is EXPECTED here: the buggy version must fail its
    # trigger test. We check for the failing_tests artefact instead.
    timeout "$T_TEST" "$D4J" test > "$LOGD/test.log" 2>&1

    if [ ! -s failing_tests ]; then
        cd "$ROOT"; fail_all "NO_FAILING_TESTS"; rm -rf "$WS"; continue
    fi

    cp failing_tests "$RES/failing_tests.txt"

    SRC_REL=$("$D4J" export -p dir.src.classes 2>/dev/null | tr -d '[:space:]')
    TESTSRC_REL=$("$D4J" export -p dir.src.tests 2>/dev/null | tr -d '[:space:]')
    BIN_REL=$("$D4J" export -p dir.bin.classes 2>/dev/null | tr -d '[:space:]')
    TESTBIN_REL=$("$D4J" export -p dir.bin.tests 2>/dev/null | tr -d '[:space:]')
    CP_TEST=$("$D4J" export -p cp.test 2>/dev/null)
    MOD_CLASS=$("$D4J" export -p classes.modified 2>/dev/null | head -1 | tr -d '[:space:]')

    TRIGGER=$("$D4J" export -p tests.trigger 2>/dev/null | head -1)
    TEST_CLASS=$(echo "$TRIGGER" | cut -d':' -f1)
    TEST_SIMPLE=$(echo "$TEST_CLASS" | awk -F'.' '{print $NF}')

    [ -d "$BIN_REL" ] || { cd "$ROOT"; fail_all "NO_BIN_DIR"; rm -rf "$WS"; continue; }

    # --- package -------------------------------------------------------
    rm -rf combined_classes; mkdir -p combined_classes
    cp -r "$BIN_REL"/* combined_classes/ 2>/dev/null
    [ -d "$TESTBIN_REL" ] && cp -r "$TESTBIN_REL"/* combined_classes/ 2>/dev/null
    find combined_classes -type f ! -name '*.class' -delete
    jar cf app.jar -C combined_classes/ . > "$LOGD/jar.log" 2>&1
    [ -s app.jar ] || { cd "$ROOT"; fail_all "JAR_FAILED"; rm -rf "$WS"; continue; }

    T_SETUP=$(( $(date +%s) - SETUP_START ))

    # --- instrument ----------------------------------------------------
    t0=$(date +%s)
    timeout "$T_INSTRUMENT" taskset -c 0 \
        java -XX:ActiveProcessorCount=1 -Xmx"$HEAP" -jar "$SLICER4J_JAR" \
             -m i -j app.jar -o slicer_workspace -lc "$LOGGER_JAR" \
             > "$LOGD/instrument.log" 2>&1
    T_INS=$(( $(date +%s) - t0 ))

    [ -f slicer_workspace/app_i.jar ] || {
        cd "$ROOT"; fail_all "INSTRUMENT_FAILED"; rm -rf "$WS"; continue; }

    # --- trace ---------------------------------------------------------
    t0=$(date +%s)
    timeout "$T_TRACE" taskset -c 0 \
        java -XX:ActiveProcessorCount=1 \
             -cp "slicer_workspace/app_i.jar:$LOGGER_JAR:$CP_TEST:$D4J_JUNIT" \
             org.junit.runner.JUnitCore "$TEST_CLASS" > trace.log 2>&1
    RC=$?
    T_TRC=$(( $(date +%s) - t0 ))

    [ "$RC" -eq 124 ] && { cd "$ROOT"; fail_all "TRACE_TIMEOUT"; rm -rf "$WS"; continue; }
    [ -s trace.log ]  || { cd "$ROOT"; fail_all "TRACE_EMPTY";   rm -rf "$WS"; continue; }

    # Match on the failure MESSAGE, not the exception class. Defects4J runs
    # tests through Ant's JUnit 3 adapter (junit.framework.AssertionFailedError)
    # while we run JUnitCore directly (org.junit.ComparisonFailure or
    # java.lang.AssertionError). Same failure, different wrapper -- matching on
    # class name flags reproduced bugs as failures.
    TRIG_METHOD=$(echo "$TRIGGER" | cut -d: -f3)

    if [ -n "$TRIG_METHOD" ] && ! grep -qF "$TRIG_METHOD" trace.log; then
        cd "$ROOT"; fail_all "NOT_REPRODUCED"
        [ "$KEEP_WORKSPACE" -eq 0 ] && rm -rf "$WS"
        continue
    fi

    # A run where EVERY test fails usually means the harness broke -- e.g.
    # test resources unreachable -- rather than the bug reproducing.
    TR=$(grep -oP 'Tests run: \K[0-9]+' trace.log | tail -1)
    TF=$(grep -oP 'Failures: \K[0-9]+' trace.log | tail -1)

    if [ -n "$TR" ] && [ -n "$TF" ] && [ "$TR" -gt 2 ] && [ "$TF" -eq "$TR" ]; then
        cd "$ROOT"; fail_all "ALL_TESTS_FAILED"
        [ "$KEEP_WORKSPACE" -eq 0 ] && rm -rf "$WS"
        continue
    fi
    TRACE_BYTES=$(stat -c%s trace.log)

    # --- baselines -----------------------------------------------------
    #
    # B1: executed statements. The key baseline -- the gap between this and
    # the slice is exactly what slicing adds over plain code coverage.
    #
    # VERIFY the extraction pattern against a real trace.log. If the logger
    # emits numeric IDs rather than class:line, resolve them through
    # slicer_workspace/static-log.log first.
    #
    grep -oE '[A-Za-z_][A-Za-z0-9_.$]*:[0-9]+' trace.log \
        | sort -u > "$RES/executed_lines.txt"
    EXEC_CLASSES=$(cut -d: -f1 "$RES/executed_lines.txt" | sed 's/\$.*//' | sort -u | wc -l | tr -d ' ')

    # B2: the modified class in full
    TOPLEVEL="${MOD_CLASS%%\$*}"
    MOD_FILE="$SRC_REL/$(echo "$TOPLEVEL" | tr '.' '/').java"
    [ -f "$MOD_FILE" ] && MODCLASS_LINES=$(grep -cvE '^[[:space:]]*($|//|/\*|\*)' "$MOD_FILE")

    # B3: whole project -- context only, never the headline number
    PROJ_LINES=$(find "$SRC_REL" -name '*.java' -exec cat {} + 2>/dev/null \
                 | grep -cvE '^[[:space:]]*($|//|/\*|\*)')

    # --- gold standard: developer-patched lines -------------------------
    #
    # Ground truth for fault coverage. Derived by diffing buggy against fixed,
    # rather than parsing Defects4J's stored patches (which are reverse
    # patches -- easy to misread in the wrong direction).
    #
    PATCH_TOTAL=0
    : > "$RES/patched_lines.txt"

    FIXED_WS="$WORK_BASE/${PROJECT}_fixed/$BUG"
    rm -rf "$FIXED_WS"
    mkdir -p "$(dirname "$FIXED_WS")"

    if timeout "$T_CHECKOUT" "$D4J" checkout -p "$PROJECT" -v "${BUG}f" -w "$FIXED_WS" \
            > "$LOGD/checkout_fixed.log" 2>&1; then

        if [ -f "$WS/$MOD_FILE" ] && [ -f "$FIXED_WS/$MOD_FILE" ]; then
            ###################################################################
            # Fault locus on the BUGGY side.
            #
            #   DELETED      a line the fix changed or removed (direct locus)
            #   ANCHOR_FWD   first statement at/after an insertion point
            #   ANCHOR_TAIL  preceding statement, when only braces follow
            #   ANCHOR_BACK  preceding statement (sensitivity analysis only)
            #
            # Writes: patched_lines.txt       primary definition
            #         patched_lines_back.txt  backward-anchor definition
            #         patched_kinds.csv       line,kind for auditing
            ###################################################################

            # --- 1. raw loci from the diff -------------------------------
            # Gate on inhunk rather than matching ---/+++ by regex: a deleted
            # line whose text starts with "--" yields "---..." and would be
            # mistaken for the header, losing an increment and shifting every
            # later line number in the hunk.
            diff -u "$WS/$MOD_FILE" "$FIXED_WS/$MOD_FILE" 2>/dev/null | awk '
                /^@@/ { h=$2; sub(/^-/,"",h); split(h,p,",")
                        old=p[1]+0; inhunk=1; next }
                inhunk==0 { next }
                /^\\/     { next }                      # "\ No newline at EOF"
                /^-/      { print old "\tDELETED";   old++; next }
                /^\+/     { print old "\tINSERT_AT"; next }
                          { old++ }                     # context line
            ' > "$RES/patched_raw.txt"

            # --- 2. which buggy-file lines are real statements ------------
            # A brace, blank, comment, annotation or import compiles to no
            # Jimple statement and can never appear in a slice, so an anchor
            # on one is unhittable and would bias coverage downward.
            awk '{
                t=$0; sub(/^[[:space:]]+/,"",t)
                if (t == "")             next
                if (t ~ /^\/\//)         next
                if (t ~ /^\/\*/)         next
                if (t ~ /^\*/)           next
                if (t ~ /^@/)            next
                if (t ~ /^package[ \t]/) next
                if (t ~ /^import[ \t]/)  next
                if (t ~ /^[{}();]*$/)    next
                print NR
            }' "$WS/$MOD_FILE" > "$RES/stmt_lines.txt"
            cp "$WS/$MOD_FILE" "$RES/modclass.java" 2>/dev/null

            # --- 3. resolve each locus to a statement line ---------------
            # FILENAME==SF rather than FNR==NR: if stmt_lines.txt is empty,
            # FNR==NR stays true for the whole second file and swallows
            # every locus.
            awk -v OFS='\t' -v SF="$RES/stmt_lines.txt" '
                FILENAME==SF { stmt[$1+0]=1
                               if ($1+0>maxl) maxl=$1+0; next }
                {
                    line=$1+0; kind=$2
                    if (kind=="DELETED") {
                        if (line in stmt) print line, "DELETED"
                        next
                    }
                    f=0; for (i=line;   i<=maxl; i++) if (i in stmt) { f=i; break }
                    b=0; for (i=line-1; i>=1;    i--) if (i in stmt) { b=i; break }
                    # Forward preferred. When only braces follow (insertion at
                    # the end of the last method) fall back to the preceding
                    # statement so the bug is not dropped; tag it separately
                    # so the fallback stays auditable.
                    if      (f>0) print f, "ANCHOR_FWD"
                    else if (b>0) print b, "ANCHOR_TAIL"
                    if (b>0) print b, "ANCHOR_BACK"
                }
            ' "$RES/stmt_lines.txt" "$RES/patched_raw.txt" \
              | sort -t"$(printf '\t')" -k1,1n -k2,2 -u \
              > "$RES/patched_resolved.txt"

            # --- 4. the two line lists, the kinds, and the counts --------
            awk -F'\t' '$2=="DELETED"||$2=="ANCHOR_FWD"||$2=="ANCHOR_TAIL"{print $1}' \
                "$RES/patched_resolved.txt" | sort -n -u > "$RES/patched_lines.txt"
            awk -F'\t' '$2=="DELETED"||$2=="ANCHOR_BACK"{print $1}' \
                "$RES/patched_resolved.txt" | sort -n -u > "$RES/patched_lines_back.txt"
            awk -F'\t' -v OFS=, '{print $1,$2}' \
                "$RES/patched_resolved.txt" > "$RES/patched_kinds.csv"

            PATCH_TOTAL=$(grep -c . "$RES/patched_lines.txt" 2>/dev/null | head -1)
            PATCH_TOTAL=${PATCH_TOTAL:-0}
            PATCH_TOTAL_BACK=$(grep -c . "$RES/patched_lines_back.txt" 2>/dev/null | head -1)
            PATCH_TOTAL_BACK=${PATCH_TOTAL_BACK:-0}

            if grep -q DELETED "$RES/patched_kinds.csv" 2>/dev/null; then
                if grep -q ANCHOR_ "$RES/patched_kinds.csv" 2>/dev/null; then
                    FAULT_KIND="MIXED"
                else
                    FAULT_KIND="DELETED"
                fi
            elif grep -q ANCHOR_ "$RES/patched_kinds.csv" 2>/dev/null; then
                FAULT_KIND="ADDITIVE"
            else
                FAULT_KIND="NONE"
            fi
    fi
    fi
    rm -rf "$FIXED_WS"

    MODELS_DIR=$(find "$SLICER4J_HOME" -type d -name "models" 2>/dev/null | head -1)

    # ======================= PHASE B: per criterion =======================

    for VARIANT in $VARIANTS
    do
	SL_MOD=""
        # ---- choose the criterion line for this variant ----------------
        CRIT=""

        case "$VARIANT" in

          test_crash)
            # Deepest frame that is TEST code: where the failure was observed.
            # Walk frames outermost-first and take the first test-code frame.
            while read -r FRAME; do
                [ -z "$FRAME" ] && continue
                FCLASS=$(echo "$FRAME" | sed 's/(.*//' | sed 's/\.[^.]*$//')
                FLINE=$(echo "$FRAME" | sed 's/.*:\([0-9]*\))/\1/')
                [ -z "$FCLASS" ] || [ -z "$FLINE" ] && continue
                # Skip framework frames outright.
                echo "$FCLASS" | grep -qE '^(junit|org\.junit|org\.apache\.tools\.ant|sun\.|java\.|jdk\.)' && continue
                if ! is_app_class "$FCLASS"; then
                    CRIT="${FCLASS}:${FLINE}"
                    break
                fi
            done <<< "$(grep -oE '[a-zA-Z0-9_.$]+\([A-Za-z0-9_]+\.java:[0-9]+\)' failing_tests)"
            ;;

          app_deepest)
            # Deepest frame that is APPLICATION code.
            while read -r FRAME; do
                [ -z "$FRAME" ] && continue
                FCLASS=$(echo "$FRAME" | sed 's/(.*//' | sed 's/\.[^.]*$//')
                FLINE=$(echo "$FRAME" | sed 's/.*:\([0-9]*\))/\1/')
                [ -z "$FCLASS" ] || [ -z "$FLINE" ] && continue
                echo "$FCLASS" | grep -qE '^(junit|org\.junit|org\.apache\.tools\.ant|sun\.|java\.|jdk\.)' && continue
                if is_app_class "$FCLASS"; then
                    CRIT="${FCLASS}:${FLINE}"
                    break
                fi
            done <<< "$(grep -oE '[a-zA-Z0-9_.$]+\([A-Za-z0-9_]+\.java:[0-9]+\)' failing_tests)"
            ;;

          patched)
            # A line the developer changed. NOTE: coverage from this variant
            # is circular by construction -- reported only to quantify how
            # much that circularity inflates the number.
            #
            # The line must also have EXECUTED, or a dynamic slicer has
            # nothing to slice from.
            PL=$(head -"$MAX_PATCHED_CRITERIA" "$RES/patched_lines.txt" | head -1)
            [ -n "$PL" ] && CRIT="${TOPLEVEL}:${PL}"
            ;;
        esac

        if [ -z "$CRIT" ]; then
            case "$VARIANT" in
              test_crash)  WHY="no frame in test class" ;;
              app_deepest) WHY="no application frame (assertion failure)" ;;
              patched)     WHY="no buggy-side patch lines (additive fix)" ;;
            esac
            echo "  [$VARIANT] -- skipped: $WHY"
            row "$VARIANT" "" "NO_CRITERION" "" "" "" "" "" "" "" ""
            continue
        fi

        echo "  [$VARIANT] $CRIT"

        SLICE_OUT="slicer_workspace"
	rm -f "$SLICE_OUT/slice.log"
        t0=$(date +%s)
        timeout "$T_SLICE" \
            java -Xmx"$HEAP" -jar "$SLICER4J_JAR" \
                 -m s -j app.jar -t trace.log \
                 -sl slicer_workspace/static-log.log \
                 -o "$SLICE_OUT" -sp "$CRIT" -lc "$LOGGER_JAR" \
                 -sd "$MODELS_DIR/summariesManual" \
                 -tw "$MODELS_DIR/EasyTaintWrapperSource.txt" \
                 > "$LOGD/slice_$VARIANT.log" 2>&1
        RC=$?
        TS=$(( $(date +%s) - t0 ))
        TRACE_SIZE=$(grep -oP 'Trace size: \K[0-9]+' "$LOGD/slice_$VARIANT.log" 2>/dev/null | tail -1)
        ICDG_BYTES=$(stat -c%s trace.log_icdg.log 2>/dev/null)
        TRACE_SIZE="${TRACE_SIZE:-}"
        ICDG_BYTES="${ICDG_BYTES:-}"

        if [ "$RC" -eq 124 ]; then
            row "$VARIANT" "$CRIT" "SLICE_TIMEOUT" "" "" "" "" "" "" "" "$TS"; continue
        fi

         if grep -q "backwardSlicePositions:[[:space:]]*$" "$LOGD/slice_$VARIANT.log" \
           || grep -q "NumberFormatException" "$LOGD/slice_$VARIANT.log"; then
            row "$VARIANT" "$CRIT" "CRITERION_NOT_EXECUTED" "" "" "" "" "" "" "" "$TS"
            continue
        fi
        if [ ! -s "$SLICE_OUT/slice.log" ]; then
            row "$VARIANT" "$CRIT" "SLICE_EMPTY" "" "" "" "" "" "" "" "$TS"; continue
        fi

        cp "$SLICE_OUT/slice.log" "$RES/slice_$VARIANT.log"

        # ---- metrics ---------------------------------------------------
        #
        # Normalise to unique (class, line). The raw log repeats statements
        # that executed many times; counting repeats would conflate "how much
        # code" with "how often it ran".
        #
        # ---- trace size -------------------------------------------------
        # "Trace size" is the number of executed statements the slicer read.
        # trace.log_icdg.log is the EXPANDED trace on disk; trace.log itself
        # is only JUnit console output plus compressed logger records, so the
        # existing trace_bytes column does not measure the trace.
	
	grep -oE '[A-Za-z_][A-Za-z0-9_.$]*:[0-9]+' "$RES/slice_$VARIANT.log" \
            | sort -u > "$RES/slice_lines_$VARIANT.txt"

	EXEC_LINES=$(grep -oP 'Trace size: \K[0-9]+' "$LOGD/slice_${VARIANT}.log" | head -1)
        EXEC_LINES="${EXEC_LINES:-}"
        EXEC_CLASSES=""
        SL=$(wc -l < "$RES/slice_lines_$VARIANT.txt" | tr -d ' ')
        SC=$(cut -d: -f1 "$RES/slice_lines_$VARIANT.txt" | sed 's/\$.*//' | sort -u | wc -l | tr -d ' ')
        SM=""   # method count: needs a class:method mapping; left for later

        RE=$(pct "$SL" "$EXEC_LINES")
        

        # ---- fault coverage against the gold standard ------------------
        PHIT=0
        COV="UNDEFINED"

        if [ "$PATCH_TOTAL" -gt 0 ]; then
            grep "^${TOPLEVEL}[:$]" "$RES/slice_lines_$VARIANT.txt" \
                | cut -d: -f2 | sort -n -u > "$RES/slice_modclass_$VARIANT.txt"
	    
	    SL_MOD=$(grep -c . "$RES/slice_modclass_$VARIANT.txt" 2>/dev/null | head -1)
	    SL_MOD=${SL_MOD:-0}
            RM=$(pct "$SL_MOD" "$MODCLASS_LINES")
	    grep -c . "$RES/patched_lines.txt" > /dev/null 2>&1 && \
            PHIT=$(grep -Fxc -f "$RES/patched_lines.txt" \
                            "$RES/slice_modclass_$VARIANT.txt" 2>/dev/null | head -1 )
	    PHIT=${PHIT:-0}
	    PHIT_BACK=$(grep -Fxc -f "$RES/patched_lines_back.txt" \
                            "$RES/slice_modclass_$VARIANT.txt"  2>/dev/null | head -1)
            PHIT_BACK=${PHIT_BACK:-0}
            if   [ "$PHIT" -eq "$PATCH_TOTAL" ]; then COV="FULL"
            elif [ "$PHIT" -gt 0 ];              then COV="PARTIAL"
            else                                      COV="NONE"
            fi
        else
            # No buggy-side lines: the fix was purely ADDITIVE. Coverage is
            # undefined here, not a miss. Report these separately.
            grep "^${TOPLEVEL}[:$]" "$RES/slice_lines_$VARIANT.txt" \
                | cut -d: -f2 | sort -n -u > "$RES/slice_modclass_$VARIANT.txt"
            SL_MOD=$(grep -c . "$RES/slice_modclass_$VARIANT.txt" 2>/dev/null | head -1)
	    SL_MOD=${SL_MOD:-0}
            RM=$(pct "$SL_MOD" "$MODCLASS_LINES")
	    COV="UNDEFINED_ADDITIVE"
        fi

        row "$VARIANT" "$CRIT" "OK" "$SL" "$SC" "$SM" "$RE" "$RM" "$PHIT" "$COV" "$TS"

    done

    cd "$ROOT"
    [ "$KEEP_WORKSPACE" -eq 0 ] && rm -rf "$WS"

done


###############################################################################
# SUMMARY
###############################################################################

echo
echo "=============================================="
echo "Finished: $PROJECT"
echo "=============================================="
echo
echo "Status by variant:"
tail -n +2 "$CSV" | awk -F, '{print $3, $5}' | sort | uniq -c | sort -rn
echo
echo "Fault coverage by variant (OK runs only):"
tail -n +2 "$CSV" | awk -F, '$5=="OK"{print $3, $17}' | sort | uniq -c
echo
echo "Median reduction vs executed, by variant:"
for V in $VARIANTS; do
    M=$(tail -n +2 "$CSV" | awk -F, -v v="$V" '$3==v && $5=="OK" && $13!=""{print $13}' \
        | sort -n | awk '{a[NR]=$1} END{if(NR) print (NR%2 ? a[(NR+1)/2] : (a[NR/2]+a[NR/2+1])/2)}')
    echo "  $V: ${M:-n/a}%"
done
echo
echo "CSV: $CSV"
