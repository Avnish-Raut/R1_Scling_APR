#!/usr/bin/env python3
"""
analyze_results.py  (v2 -- matches the 26-column CSV with fault_kind)

Turns the per-bug CSVs from run_slicer.sh into the statistics and figures a
paper needs.

    pip3 install pandas numpy scipy matplotlib --break-system-packages

    python3 analyze_results.py /home/research_slicing/slicer4j/results

Reads every <Project>_rq.csv in that directory, writes figures and tables to
./analysis_output/.

---------------------------------------------------------------------------
WHAT CHANGED FROM v1, AND WHY
---------------------------------------------------------------------------

Three things in v1 would not have survived review.

1. DEGENERATE SLICES WERE SILENTLY AVERAGED IN.
   30 rows reported exactly 100% reduction vs the modified class. That is
   not a 100% reduction -- it means the slice contained ZERO lines of the
   modified class, so the slicer never reached the faulty code at all. 20 of
   those also had NONE coverage, which confirms it. Averaging them into the
   reduction figure inflates it with the slicer's failures.

   v2 splits them out: reduction is computed over rows with
   slice_modclass > 0, and the degenerate rows are reported as their own
   category. Both numbers go in the paper.

2. COVERAGE HAD ONE DEFINITION WHERE IT NEEDS TWO.
   Purely additive fixes have no buggy-side line to find. v1 dropped them
   (UNDEFINED_ADDITIVE), which cut Lang's app_deepest denominator to n=9.
   The runner now maps them to an insertion anchor and records fault_kind.

   v2 reports coverage twice:
     strict     -- DELETED bugs only. No convention, nothing to defend.
     inclusive  -- plus ADDITIVE/MIXED via the anchor rule, comparable to
                   prior fault-localisation work (Pearson et al. ICSE 2017).
   The gap between them is itself a reportable finding.

3. NO MULTIPLE-COMPARISON CORRECTION.
   Three pairwise Wilcoxon tests on the same data, one of which came back
   p=0.048. That is exactly the situation Holm correction exists for. v2
   applies it and reports both raw and adjusted p.

---------------------------------------------------------------------------
WHY THESE STATISTICS AND NOT OTHERS
---------------------------------------------------------------------------

Slice sizes are heavily right-skewed: most slices are small, a few are huge.

1. MEDIAN AND IQR, NOT MEAN AND SD.
   A mean on skewed data is dragged around by outliers and describes no
   typical bug. The median does.

2. NON-PARAMETRIC TESTS.
   A t-test assumes normality. Slice sizes are not normal. Wilcoxon
   signed-rank is the paired non-parametric equivalent.

3. EFFECT SIZE, NOT JUST p-VALUES.
   With ~200 bugs a trivial difference can be "significant". Cliff's delta
   says how large it is, independent of sample size.

Comparisons between criterion variants are PAIRED: the same bug is sliced
under each variant. Only bugs where BOTH variants succeeded can be compared.
"""

import sys
import os
import glob

import numpy as np
import pandas as pd
from scipy import stats

import matplotlib
matplotlib.use("Agg")           # no display on the VM
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# Effect size: Cliff's delta
#
# Not in scipy, so implemented here. The probability that a randomly chosen
# value from x exceeds one from y, minus the reverse. Range -1..1.
#
# Magnitude thresholds (Romano et al.):
#   |d| < 0.147  negligible
#   |d| < 0.330  small
#   |d| < 0.474  medium
#   otherwise    large
# ---------------------------------------------------------------------------

def cliffs_delta(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if len(x) == 0 or len(y) == 0:
        return np.nan, "n/a"

    greater = sum((xi > y).sum() for xi in x)
    less = sum((xi < y).sum() for xi in x)
    d = (greater - less) / (len(x) * len(y))

    a = abs(d)
    if a < 0.147:
        mag = "negligible"
    elif a < 0.330:
        mag = "small"
    elif a < 0.474:
        mag = "medium"
    else:
        mag = "large"
    return d, mag


# ---------------------------------------------------------------------------
# Wilson score interval for a proportion.
#
# Preferred over the normal approximation, which behaves badly for small
# samples and for proportions near 0 or 1 -- both common here.
# ---------------------------------------------------------------------------

def wilson_ci(successes, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = successes / n
    denom = 1 + z**2 / n
    centre = (p + z**2 / (2 * n)) / denom
    half = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


# ---------------------------------------------------------------------------
# Holm-Bonferroni step-down correction.
#
# Controls the family-wise error rate across a set of related tests. Less
# conservative than plain Bonferroni and uniformly more powerful, with no
# extra assumptions -- there is no reason to use Bonferroni instead.
#
# Returns adjusted p-values in the same order as the input.
# ---------------------------------------------------------------------------

def holm(pvals):
    p = np.asarray(pvals, dtype=float)
    m = len(p)
    if m == 0:
        return p
    order = np.argsort(np.nan_to_num(p, nan=1.0))
    adj = np.ones(m)
    running = 0.0
    for rank, idx in enumerate(order):
        if np.isnan(p[idx]):
            adj[idx] = np.nan
            continue
        running = max(running, (m - rank) * p[idx])
        adj[idx] = min(1.0, running)
    return adj


def describe(series, label):
    """Median-centred summary. Returns a dict for the summary table."""
    s = pd.to_numeric(series, errors="coerce").dropna()
    if len(s) == 0:
        return {"metric": label, "n": 0}
    return {
        "metric": label,
        "n": len(s),
        "min": round(s.min(), 2),
        "q1": round(s.quantile(0.25), 2),
        "median": round(s.median(), 2),
        "q3": round(s.quantile(0.75), 2),
        "max": round(s.max(), 2),
        "iqr": round(s.quantile(0.75) - s.quantile(0.25), 2),
        "mean": round(s.mean(), 2),     # for comparison with median only
    }


# Coverage labels that represent a real measurement.
DEFINED = ["FULL", "PARTIAL", "NONE"]


def main():

    if len(sys.argv) < 2:
        print("Usage: python3 analyze_results.py <results-dir>")
        sys.exit(1)

    results_dir = sys.argv[1]
    out_dir = os.path.join(os.getcwd(), "analysis_output")
    os.makedirs(out_dir, exist_ok=True)

    # -----------------------------------------------------------------------
    # LOAD
    # -----------------------------------------------------------------------

    files = sorted(glob.glob(os.path.join(results_dir, "*_rq.csv")))
    if not files:
        print(f"No *_rq.csv found in {results_dir}")
        sys.exit(1)

    frames = []
    for f in files:
        try:
            frames.append(pd.read_csv(f))
        except Exception as e:
            print(f"WARNING: could not read {f}: {e}")
    if not frames:
        sys.exit(1)

    df = pd.concat(frames, ignore_index=True)

    NUMERIC = ["bug", "slice_lines", "slice_classes", "slice_methods",
               "executed_lines", "executed_classes", "modclass_lines",
               "project_lines", "red_vs_executed", "red_vs_modclass",
               "patch_total", "patch_in_slice",
               "t_setup", "t_instrument", "t_trace", "t_slice",
               "trace_bytes", "trace_size", "icdg_bytes", "slice_modclass"]
    for c in NUMERIC:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    HAS_MODSLICE = "slice_modclass" in df.columns
    HAS_KIND = "fault_kind" in df.columns

    print(f"Loaded {len(df)} rows from {len(files)} file(s)")
    print(f"Projects: {sorted(df['project'].dropna().unique())}")
    print(f"Columns:  {len(df.columns)}"
          f"   slice_modclass={'yes' if HAS_MODSLICE else 'NO'}"
          f"   fault_kind={'yes' if HAS_KIND else 'NO'}")
    if not HAS_MODSLICE:
        print("  -> degenerate-slice split unavailable; reduction figures will")
        print("     include rows where the slice never reached the faulty class.")
    if not HAS_KIND:
        print("  -> fault_kind absent; only the strict coverage definition is")
        print("     reported (additive fixes excluded, as in v1).")
    print()

    ok = df[df["status"] == "OK"].copy()
    variants = sorted(ok["variant"].dropna().unique())

    report = []
    def say(line=""):
        print(line)
        report.append(str(line))

    # =======================================================================
    # 1. FEASIBILITY -- which bugs could be sliced at all
    #
    # A result in its own right. The Slicer4J paper evaluates on a curated
    # benchmark; a per-project success rate across all of Defects4J is new
    # information.
    # =======================================================================

    say("=" * 74)
    say("1. FEASIBILITY")
    say("=" * 74)

    feas = (df.groupby(["project", "variant", "status"])
              .size().unstack(fill_value=0))
    say(feas.to_string())
    say()

    say("Pipeline feasibility (test_crash = the always-available criterion):")
    tot_ok = tot_n = 0
    for proj in sorted(df["project"].dropna().unique()):
        sub = df[(df["project"] == proj) & (df["variant"] == "test_crash")]
        n_ok = (sub["status"] == "OK").sum()
        n = len(sub)
        if n == 0:
            continue
        tot_ok += n_ok
        tot_n += n
        lo, hi = wilson_ci(n_ok, n)
        say(f"  {proj:10s} {n_ok:3d}/{n:3d} sliced "
            f"({100*n_ok/n:5.1f}%, 95% CI [{100*lo:.1f}, {100*hi:.1f}])")
    if tot_n:
        lo, hi = wilson_ci(tot_ok, tot_n)
        say(f"  {'TOTAL':10s} {tot_ok:3d}/{tot_n:3d} sliced "
            f"({100*tot_ok/tot_n:5.1f}%, 95% CI [{100*lo:.1f}, {100*hi:.1f}])")
    say()

    feas.to_csv(os.path.join(out_dir, "feasibility.csv"))

    # =======================================================================
    # 2. DEGENERATE SLICES
    #
    # A slice with zero lines of the modified class did not reduce that class
    # by 100% -- it missed it entirely. These must come out of the reduction
    # figures and be reported on their own.
    # =======================================================================

    say("=" * 74)
    say("2. DEGENERATE SLICES (slice never reached the modified class)")
    say("=" * 74)

    if HAS_MODSLICE:
        ok["degenerate"] = ok["slice_modclass"].fillna(0) <= 0
        ok_nd = ok[~ok["degenerate"]].copy()          # nd = non-degenerate

        for v in variants:
            sub = ok[ok["variant"] == v]
            if len(sub) == 0:
                continue
            nd = int((~sub["degenerate"]).sum())
            dg = int(sub["degenerate"].sum())
            say(f"  {v:12s} usable {nd:3d}   degenerate {dg:3d}"
                f"   ({100*dg/len(sub):.1f}% of OK runs)")

        say()
        say("Cross-check against fault coverage -- a degenerate slice should")
        say("almost always show NONE, because a slice that excludes the whole")
        say("modified class cannot contain a patched line:")
        say()
        xt = (ok.groupby(["degenerate", "coverage"]).size()
                .unstack(fill_value=0))
        say(xt.to_string())
        say()

        dg_rows = ok[ok["degenerate"]]
        if len(dg_rows):
            dg_rows[["project", "bug", "variant", "criterion", "coverage",
                     "slice_lines", "slice_classes", "modclass_lines"]] \
                .to_csv(os.path.join(out_dir, "degenerate_slices.csv"),
                        index=False)
            say(f"{len(dg_rows)} degenerate rows listed in "
                f"degenerate_slices.csv -- inspect a few by hand. The usual")
            say("cause is a criterion whose backward slice stays inside the")
            say("test or framework code and never crosses into the fix site.")
        say()
    else:
        ok_nd = ok.copy()
        say("slice_modclass column absent -- cannot identify degenerate")
        say("slices. Rerun with the current run_slicer.sh.")
        say()

    # =======================================================================
    # 3. SLICE SIZE AND REDUCTION  (RQ3)
    # =======================================================================

    say("=" * 74)
    say("3. SLICE SIZE AND REDUCTION")
    say("=" * 74)
    say("Reduction vs the modified class is computed over NON-DEGENERATE runs")
    say("only. Slice size is reported over all OK runs, since a small slice is")
    say("a real measurement even when it misses the fix.")
    say()

    rows = []
    for v in variants:
        sub_all = ok[ok["variant"] == v]
        sub_nd = ok_nd[ok_nd["variant"] == v]
        rows.append(describe(sub_all["slice_lines"], f"{v}: slice size (lines)"))
        rows.append(describe(sub_all["slice_classes"], f"{v}: classes touched"))
        rows.append(describe(sub_nd["red_vs_executed"],
                             f"{v}: reduction vs executed (%)  [non-degen]"))
        rows.append(describe(sub_nd["red_vs_modclass"],
                             f"{v}: reduction vs mod class (%) [non-degen]"))

    size_tbl = pd.DataFrame(rows)
    say(size_tbl.to_string(index=False))
    say()
    say("Note the gap between mean and median on slice size: that gap is why")
    say("the median is the number to report.")
    say()

    size_tbl.to_csv(os.path.join(out_dir, "slice_size_summary.csv"), index=False)

    # =======================================================================
    # 4. CRITERION SENSITIVITY  (RQ1) -- paired, Holm-corrected
    # =======================================================================

    say("=" * 74)
    say("4. CRITERION SENSITIVITY (paired, Holm-corrected)")
    say("=" * 74)

    tests = []
    for i in range(len(variants)):
        for j in range(i + 1, len(variants)):
            v1, v2 = variants[i], variants[j]

            a = (ok[ok["variant"] == v1]
                 .drop_duplicates(subset=["project", "bug"])
                 .set_index(["project", "bug"])["slice_lines"])
            b = (ok[ok["variant"] == v2]
                 .drop_duplicates(subset=["project", "bug"])
                 .set_index(["project", "bug"])["slice_lines"])

            # Pair on bugs where BOTH variants succeeded. Comparing unpaired
            # populations would confound criterion choice with which bugs
            # happened to work under each.
            common = a.index.intersection(b.index)
            common = [k for k in common
                      if pd.notna(a.loc[k]) and pd.notna(b.loc[k])]

            if len(common) < 5:
                tests.append({"pair": f"{v1} vs {v2}", "n": len(common),
                              "p": np.nan, "d": np.nan, "mag": "too few",
                              "m1": np.nan, "m2": np.nan})
                continue

            x = np.array([a.loc[k] for k in common], dtype=float)
            y = np.array([b.loc[k] for k in common], dtype=float)

            try:
                _, p = stats.wilcoxon(x, y)
            except ValueError:          # all differences zero
                p = np.nan

            d, mag = cliffs_delta(x, y)
            tests.append({"pair": f"{v1} vs {v2}", "n": len(common),
                          "p": p, "d": d, "mag": mag,
                          "m1": np.median(x), "m2": np.median(y)})

    # Correct across the whole family of pairwise tests, not one at a time.
    adj = holm([t["p"] for t in tests])
    for t, pa in zip(tests, adj):
        t["p_holm"] = pa

    for t in tests:
        say(f"{t['pair']}  (n={t['n']} paired bugs)")
        if t["n"] < 5:
            say("  too few paired bugs to test")
            say()
            continue
        say(f"  median: {t['m1']:.0f} vs {t['m2']:.0f} lines")
        say(f"  Wilcoxon signed-rank: p = {t['p']:.4g}"
            f"   Holm-adjusted p = {t['p_holm']:.4g}")
        say(f"  Cliff's delta: {t['d']:+.3f} ({t['mag']})")
        say()

    sig = [t for t in tests if pd.notna(t.get("p_holm")) and t["p_holm"] < 0.05]
    if sig:
        say("Surviving correction at alpha=0.05: "
            + ", ".join(t["pair"] for t in sig))
    else:
        say("NOTHING survives Holm correction. The honest claim is that slice")
        say("SIZE does not differ meaningfully by criterion -- which makes the")
        say("coverage difference in section 5 the interesting result, since")
        say("the criteria cost the same but do not find the fault equally.")
    say()

    pd.DataFrame(tests).to_csv(
        os.path.join(out_dir, "criterion_tests.csv"), index=False)

    # =======================================================================
    # 5. FAULT COVERAGE  (RQ2) -- strict and inclusive
    # =======================================================================

    say("=" * 74)
    say("5. FAULT COVERAGE")
    say("=" * 74)

    cov = ok.groupby(["variant", "coverage"]).size().unstack(fill_value=0)
    say("Raw counts:")
    say(cov.to_string())
    say()

    if HAS_KIND:
        say("By fault kind (how the developer fixed it, not how the slicer did):")
        kind_tbl = (ok.drop_duplicates(subset=["project", "bug"])
                      .groupby(["project", "fault_kind"])
                      .size().unstack(fill_value=0))
        say(kind_tbl.to_string())
        say()
        say("  DELETED  = the fix changed or removed lines -> direct fault locus")
        say("  ADDITIVE = the fix only inserted lines -> omission fault, located")
        say("             by anchoring on the preceding statement")
        say("  MIXED    = both")
        say()
        kind_tbl.to_csv(os.path.join(out_dir, "fault_kinds.csv"))

    cov_rows = []
    for v in variants:
        sub = ok[ok["variant"] == v]

        say(f"--- {v} ---")

        definitions = [("strict (DELETED only)", ["DELETED"])]
        if HAS_KIND:
            definitions.append(
                ("inclusive (+ anchored additive)",
                 ["DELETED", "MIXED", "ADDITIVE"]))

        for label, kinds in definitions:
            if HAS_KIND:
                pool = sub[sub["fault_kind"].isin(kinds)]
            else:
                # No fault_kind: fall back to v1 behaviour.
                pool = sub
                label = "strict (additive excluded by the runner)"

            defined = pool[pool["coverage"].isin(DEFINED)]
            excluded = len(pool) - len(defined)

            if len(defined) == 0:
                say(f"  {label}: no bugs with defined coverage")
                continue

            full = (defined["coverage"] == "FULL").sum()
            part = (defined["coverage"] == "PARTIAL").sum()
            none = (defined["coverage"] == "NONE").sum()
            lo, hi = wilson_ci(full, len(defined))
            lo2, hi2 = wilson_ci(full + part, len(defined))

            say(f"  {label}:  n = {len(defined)}"
                + (f"  ({excluded} excluded as undefined)" if excluded else ""))
            say(f"    FULL        {full:3d}  ({100*full/len(defined):5.1f}%, "
                f"CI [{100*lo:.1f}, {100*hi:.1f}])")
            say(f"    PARTIAL     {part:3d}  ({100*part/len(defined):5.1f}%)")
            say(f"    NONE        {none:3d}  ({100*none/len(defined):5.1f}%)")
            say(f"    any contact {full+part:3d}  "
                f"({100*(full+part)/len(defined):5.1f}%, "
                f"CI [{100*lo2:.1f}, {100*hi2:.1f}])")

            # Line-level recall: of all patched lines, how many were captured?
            tot_patch = defined["patch_total"].sum()
            tot_hit = defined["patch_in_slice"].sum()
            if tot_patch and tot_patch > 0:
                say(f"    line recall {tot_hit:.0f}/{tot_patch:.0f}  "
                    f"({100*tot_hit/tot_patch:5.1f}%)")

            cov_rows.append({
                "variant": v, "definition": label, "n": len(defined),
                "full": full, "partial": part, "none": none,
                "full_pct": round(100*full/len(defined), 1),
                "any_pct": round(100*(full+part)/len(defined), 1),
            })
        say()

    if HAS_KIND and len(cov_rows) >= 2:
        say("The gap between strict and inclusive is the cost of the anchoring")
        say("convention. If the two agree, the convention is not driving the")
        say("result and you can report the inclusive number with confidence.")
        say("If they disagree, report both and say so.")
        say()

    cov.to_csv(os.path.join(out_dir, "fault_coverage.csv"))
    pd.DataFrame(cov_rows).to_csv(
        os.path.join(out_dir, "coverage_both_definitions.csv"), index=False)

    # =======================================================================
    # 6. COST  (RQ4)
    # =======================================================================

    say("=" * 74)
    say("6. COST")
    say("=" * 74)

    # Setup/instrument/trace repeat across a bug's variants, so deduplicate
    # by bug before summarising -- otherwise the totals are inflated.
    per_bug = ok.drop_duplicates(subset=["project", "bug"])

    for c, label in [("t_setup", "setup (checkout+compile+test)"),
                     ("t_instrument", "instrumentation"),
                     ("t_trace", "trace execution")]:
        if c not in per_bug.columns:
            continue
        s = per_bug[c].dropna()
        if len(s):
            say(f"  {label:32s} median {s.median():6.1f}s  "
                f"IQR [{s.quantile(.25):.0f}, {s.quantile(.75):.0f}]  "
                f"max {s.max():.0f}s")

    s = ok["t_slice"].dropna()
    if len(s):
        say(f"  {'slicing (per criterion)':32s} median {s.median():6.1f}s  "
            f"IQR [{s.quantile(.25):.0f}, {s.quantile(.75):.0f}]  "
            f"max {s.max():.0f}s")
    say()

    if "trace_size" in per_bug.columns:
        t = per_bug["trace_size"].dropna()
        if len(t):
            say(f"  trace length (entries): median {t.median():,.0f}  "
                f"min {t.min():,.0f}  max {t.max():,.0f}")
    if "icdg_bytes" in per_bug.columns:
        g = per_bug["icdg_bytes"].dropna()
        if len(g):
            say(f"  dependence graph on disk: median {g.median()/1e6:,.1f} MB  "
                f"max {g.max()/1e9:,.2f} GB")
    say()
    say("Slicing is cheap relative to setup and tracing, which is why extra")
    say("criteria per bug cost almost nothing. Report setup and slicing")
    say("separately -- the setup cost is Defects4J's, not the slicer's.")
    say()

    # Does trace length predict slicing time? Relevant to scalability claims.
    if "trace_size" in ok.columns:
        v = ok[["trace_size", "t_slice"]].dropna()
        if len(v) > 5:
            rho, p = stats.spearmanr(v["trace_size"], v["t_slice"])
            say(f"Spearman (trace length vs slicing time): "
                f"rho = {rho:.3f}, p = {p:.4g}, n = {len(v)}")
            say()

    # =======================================================================
    # FIGURES
    # =======================================================================

    print("Writing figures...")

    def save(fig, name):
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, name), dpi=200)
        plt.close(fig)

    # --- Fig 1: distribution of slice size by variant ---------------------
    # A box plot shows median, spread and outliers at once -- the right choice
    # for skewed data. A bar chart of means would hide all of it.
    fig, ax = plt.subplots(figsize=(7, 4.5))
    data, labels = [], []
    for v in variants:
        s = ok[ok["variant"] == v]["slice_lines"].dropna()
        if len(s):
            data.append(s.values)
            labels.append(f"{v}\n(n={len(s)})")
    if data:
        try:
            ax.boxplot(data, tick_labels=labels, showfliers=True)
        except TypeError:                      # matplotlib < 3.9
            ax.boxplot(data, labels=labels, showfliers=True)
        ax.set_ylabel("Slice size (distinct source lines)")
        ax.set_title("Slice size by criterion variant")
        ax.set_yscale("log")        # the data spans orders of magnitude
        ax.grid(axis="y", alpha=0.3)
        save(fig, "fig1_slice_size_by_variant.png")
    else:
        plt.close(fig)

    # --- Fig 2: ECDF of reduction (non-degenerate only) -------------------
    # An empirical CDF shows the whole distribution without binning choices.
    # Read it as "X% of bugs achieved at most Y% reduction".
    fig, ax = plt.subplots(figsize=(7, 4.5))
    any_line = False
    for v in variants:
        s = (ok_nd[ok_nd["variant"] == v]["red_vs_modclass"]
             .dropna().sort_values())
        if len(s):
            ax.step(s.values, np.arange(1, len(s) + 1) / len(s),
                    where="post", label=f"{v} (n={len(s)})")
            any_line = True
    ax.set_xlabel("Reduction vs modified class (%)")
    ax.set_ylabel("Cumulative fraction of bugs")
    ax.set_title("Code reduction, degenerate slices excluded")
    if any_line:
        ax.legend()
    ax.grid(alpha=0.3)
    save(fig, "fig2_reduction_ecdf.png")

    # --- Fig 3: slice size vs class size ----------------------------------
    # Does slicing scale? If points hug the diagonal the slice is nearly the
    # whole class and slicing is not helping. Log-log: both span orders of
    # magnitude.
    sub = ok[ok["variant"] == "test_crash"]
    valid = sub[["modclass_lines", "slice_lines"]].dropna()
    valid = valid[(valid["modclass_lines"] > 0) & (valid["slice_lines"] > 0)]
    if len(valid) > 2:
        fig, ax = plt.subplots(figsize=(6, 6))
        ax.scatter(valid["modclass_lines"], valid["slice_lines"],
                   alpha=0.6, s=25)
        hi_lim = max(valid["modclass_lines"].max(),
                     valid["slice_lines"].max()) * 1.3
        ax.plot([1, hi_lim], [1, hi_lim], "k--", lw=1,
                label="slice = whole class")
        ax.set_xscale("log"); ax.set_yscale("log")
        ax.set_xlabel("Lines in modified class")
        ax.set_ylabel("Lines in slice")
        ax.set_title("Slice size vs class size (test_crash)")
        ax.legend(); ax.grid(alpha=0.3)
        save(fig, "fig3_slice_vs_class.png")

        # Spearman rather than Pearson: tests a monotonic relationship without
        # assuming linearity or normality.
        rho, p = stats.spearmanr(valid["modclass_lines"], valid["slice_lines"])
        say(f"Spearman (class size vs slice size): "
            f"rho = {rho:.3f}, p = {p:.4g}, n = {len(valid)}")
        say()

    # --- Fig 4: paired slope plot -----------------------------------------
    # One line per bug, connecting its slice size under each variant. Shows
    # not just the average difference but whether the effect is consistent --
    # crossing lines mean the ranking flips between bugs.
    if len(variants) >= 2:
        v1, v2 = variants[0], variants[1]
        a = (ok[ok["variant"] == v1].drop_duplicates(subset=["project", "bug"])
             .set_index(["project", "bug"])["slice_lines"])
        b = (ok[ok["variant"] == v2].drop_duplicates(subset=["project", "bug"])
             .set_index(["project", "bug"])["slice_lines"])
        common = [k for k in a.index.intersection(b.index)
                  if pd.notna(a.loc[k]) and pd.notna(b.loc[k])
                  and a.loc[k] > 0 and b.loc[k] > 0]
        if common:
            fig, ax = plt.subplots(figsize=(5, 6))
            for k in common:
                ax.plot([0, 1], [a.loc[k], b.loc[k]], "-o",
                        color="steelblue", alpha=0.45, ms=4)
            ax.set_xticks([0, 1]); ax.set_xticklabels([v1, v2])
            ax.set_ylabel("Slice size (lines)")
            ax.set_yscale("log")
            ax.set_title(f"Per-bug change: {v1} -> {v2}\n(n={len(common)})")
            ax.grid(axis="y", alpha=0.3)
            save(fig, "fig4_paired_slope.png")

    # --- Fig 5: status breakdown ------------------------------------------
    # The failure taxonomy as a figure. Stacked bars per project.
    tc = df[df["variant"] == "test_crash"]
    ct = tc.groupby(["project", "status"]).size().unstack(fill_value=0)
    if not ct.empty:
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ct.plot(kind="bar", stacked=True, ax=ax, colormap="tab20")
        ax.set_ylabel("Bugs")
        ax.set_title("Outcome by project (test_crash criterion)")
        ax.legend(fontsize=7, bbox_to_anchor=(1.02, 1), loc="upper left")
        save(fig, "fig5_status_by_project.png")

    # --- Fig 6: coverage, strict vs inclusive -----------------------------
    if cov_rows:
        cdf = pd.DataFrame(cov_rows)
        fig, ax = plt.subplots(figsize=(7.5, 4.5))
        pivot = cdf.pivot_table(index="variant", columns="definition",
                                values="full_pct")
        pivot.plot(kind="bar", ax=ax)
        ax.set_ylabel("FULL coverage (% of defined bugs)")
        ax.set_title("Fault coverage under both definitions")
        ax.set_ylim(0, 100)
        ax.legend(fontsize=8)
        ax.grid(axis="y", alpha=0.3)
        save(fig, "fig6_coverage_definitions.png")

    # --- Fig 7: degenerate share ------------------------------------------
    if HAS_MODSLICE:
        shares = []
        for v in variants:
            sub_v = ok[ok["variant"] == v]
            if len(sub_v):
                shares.append((v, (~sub_v["degenerate"]).sum(),
                               sub_v["degenerate"].sum()))
        if shares:
            fig, ax = plt.subplots(figsize=(6.5, 4))
            names = [s[0] for s in shares]
            usable = [s[1] for s in shares]
            degen = [s[2] for s in shares]
            ax.bar(names, usable, label="reached modified class")
            ax.bar(names, degen, bottom=usable, label="degenerate (missed it)")
            ax.set_ylabel("OK runs")
            ax.set_title("Did the slice reach the faulty class?")
            ax.legend(fontsize=8)
            ax.grid(axis="y", alpha=0.3)
            save(fig, "fig7_degenerate.png")

    # -----------------------------------------------------------------------
    # SAVE
    # -----------------------------------------------------------------------

    with open(os.path.join(out_dir, "report.txt"), "w") as f:
        f.write("\n".join(report) + "\n")

    ok.to_csv(os.path.join(out_dir, "successful_runs.csv"), index=False)
    if HAS_MODSLICE:
        ok_nd.to_csv(os.path.join(out_dir, "successful_nondegenerate.csv"),
                     index=False)

    print()
    print(f"Wrote tables and figures to {out_dir}/")
    for name, what in [
        ("report.txt", "full text report (paste numbers from here)"),
        ("feasibility.csv", "status counts per project/variant"),
        ("degenerate_slices.csv", "runs where the slice missed the fix class"),
        ("slice_size_summary.csv", "median/IQR table"),
        ("criterion_tests.csv", "Wilcoxon + Cliff's delta, Holm-adjusted"),
        ("fault_coverage.csv", "raw coverage counts"),
        ("coverage_both_definitions.csv", "strict vs inclusive coverage"),
        ("fault_kinds.csv", "DELETED / ADDITIVE / MIXED per project"),
        ("fig1_slice_size_by_variant.png", "distribution by criterion"),
        ("fig2_reduction_ecdf.png", "reduction distribution"),
        ("fig3_slice_vs_class.png", "does slicing scale"),
        ("fig4_paired_slope.png", "per-bug criterion effect"),
        ("fig5_status_by_project.png", "failure taxonomy"),
        ("fig6_coverage_definitions.png", "strict vs inclusive coverage"),
        ("fig7_degenerate.png", "share of slices that missed the fix class"),
    ]:
        if os.path.exists(os.path.join(out_dir, name)):
            print(f"  {name:34s} {what}")


if __name__ == "__main__":
    main()
