# Quick-reference numbers

Generated from `data/final/` (846 rows). `analysis/report.txt` is authoritative; this is for checking a figure without opening it.


## Status, all runs

| status | runs |
| --- | --- |
| OK | 492 |
| NO_CRITERION | 187 |
| CRITERION_NOT_EXECUTED | 54 |
| SLICE_TIMEOUT | 54 |
| TRACE_TIMEOUT | 27 |
| SLICE_EMPTY | 26 |
| NOT_REPRODUCED | 3 |
| ALL_TESTS_FAILED | 3 |

## Feasibility, test_crash

| project | sliced | rate | 95% CI |
| --- | --- | --- | --- |
| Chart | 23/26 | 88.5% | [71.0, 96.0] |
| Cli | 38/39 | 97.4% | [86.8, 99.5] |
| Compress | 43/47 | 91.5% | [80.1, 96.6] |
| Lang | 55/64 | 85.9% | [75.4, 92.4] |
| Math | 67/106 | 63.2% | [53.7, 71.8] |
| **all** | **226/282** | **80.1%** | **[75.1, 84.4]** |

## Coverage by criterion, rule C

| criterion | n OK | FULL | PARTIAL | NONE | FULL % | any contact % |
| --- | --- | --- | --- | --- | --- | --- |
| test_crash | 226 | 44 | 66 | 116 | 19.5% | 48.7% |
| app_deepest | 79 | 19 | 42 | 18 | 24.1% | 77.2% |
| patched | 187 | 55 | 132 | 0 | 29.4% | 100.0% |

## Reminders

- `patched` is a circular oracle bound, never a slicer capability.
- `app_deepest` is measured on a smaller, different bug population.
- FULL coverage is rule-dependent; lead with any-contact.
- `t_trace` is broken and must not be reported.
- Stock-tool figures come from `data/stock/`, not `data/final/`.

